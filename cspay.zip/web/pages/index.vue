<!-- pages/index.vue (landing) -->
<template>
  <div class="landing">
    <header class="nav" :class="{ 'nav-on': isScrolled }">
      <div class="nav-in">
        <NuxtLink to="/" class="brand"><SiteLogo /></NuxtLink>
        <nav class="links">
          <a href="#api">API</a>
          <a href="#fitur">Fitur</a>
          <a href="#biaya">Biaya</a>
          <a href="#alur">Alur</a>
          <NuxtLink to="/docs">Docs</NuxtLink>
        </nav>
        <div class="cta-nav">
          <NuxtLink to="/login" class="btn-soft">Masuk</NuxtLink>
          <NuxtLink to="/register" class="btn-grad">Daftar</NuxtLink>
        </div>
      </div>
    </header>

    <!-- HERO 3D -->
    <section class="hero">
      <div class="hero-grid" aria-hidden="true"></div>
      <div class="hero-glow g1" aria-hidden="true"></div>
      <div class="hero-glow g2" aria-hidden="true"></div>
      <div class="wrap hero-in">
        <div class="hero-copy">
          <div class="chip"><i class="dot"></i> QRIS aktif, deteksi otomatis</div>
          <h1 class="h1">{{ titleParts[0] }}<span v-if="titleParts[1]" class="mark">{{ titleParts[1] }}</span>{{ titleParts[2] }}</h1>
          <p class="sub">{{ heroLead }}</p>
          <div class="hero-cta">
            <NuxtLink to="/register" class="btn-grad btn-xl">Buat akun sekarang</NuxtLink>
            <a href="#api" class="btn-ghost btn-xl">Lihat contoh API</a>
          </div>
          <dl class="hero-stats">
            <div><dt>{{ feeTransactionPercent }}%</dt><dd>Fee per transaksi</dd></div>
            <div><dt>7 dtk</dt><dd>Interval deteksi</dd></div>
            <div><dt>12x</dt><dd>Retry callback</dd></div>
          </dl>
        </div>

        <div class="stage" ref="stage" @pointermove="onMove" @pointerleave="onLeave" aria-hidden="true">
          <div class="scene" :style="{ transform: `rotateX(${rx}deg) rotateY(${ry}deg)` }">
            <div class="floor"></div>

            <!-- panel dasar -->
            <div class="plate">
              <div class="plate-bar"><i></i><i></i><i></i></div>
              <div class="plate-row"><span>Saldo tersedia</span><b>Rp 4.820.000</b></div>
              <svg class="plate-chart" viewBox="0 0 220 70" preserveAspectRatio="none">
                <defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#14b8a6" stop-opacity=".5"/><stop offset="1" stop-color="#14b8a6" stop-opacity="0"/></linearGradient></defs>
                <path d="M0 58 L25 46 L50 52 L80 30 L110 38 L140 18 L170 26 L220 6 L220 70 L0 70Z" fill="url(#lg)"/>
                <path d="M0 58 L25 46 L50 52 L80 30 L110 38 L140 18 L170 26 L220 6" fill="none" stroke="#5eead4" stroke-width="2" stroke-linejoin="round"/>
              </svg>
            </div>

            <!-- notifikasi lunas -->
            <div class="paid">
              <div class="paid-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div>
              <div><b>Pembayaran diterima</b><span>CSP-10001 &middot; Rp 25.000</span></div>
            </div>
            <!-- kartu ringkas -->
            <div class="stat">
              <span>Rata-rata deteksi</span>
              <b>7 detik</b>
              <i><u style="width:82%"></u></i>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- MARQUEE BANK -->
    <section class="mq" v-if="marquee.length">
      <p class="mq-t">{{ marqueeText }}</p>
      <div class="mq-view">
        <div class="mq-track" :style="{ '--n': marquee.length }">
          <template v-for="r in 2" :key="r">
            <div v-for="b in marquee" :key="r + b.code" class="mq-item" :aria-hidden="r === 2">
              <img v-if="b.logo" :src="b.logo" :alt="b.name" loading="lazy" />
              <span v-else>{{ b.name }}</span>
            </div>
          </template>
        </div>
      </div>
    </section>

    <!-- API -->
    <section id="api" class="api">
      <div class="wrap">
        <div class="api-head" v-reveal>
          <div>
            <span class="tag">API</span>
            <h2>Integrasi <em>5 menit</em> beres</h2>
          </div>
          <NuxtLink to="/docs" class="btn-ghost-d">Baca dokumentasi</NuxtLink>
        </div>

        <div class="api-shell" v-reveal>
          <div class="api-tabs">
            <button v-for="t in Object.keys(snippets)" :key="t" class="api-tab" :class="{ active: tab === t }" @click="tab = t">{{ t }}</button>
            <button class="api-copy" @click="copyCode">{{ copied ? 'Tersalin' : 'Salin' }}</button>
          </div>
          <pre class="api-code"><code>{{ snippets[tab] }}</code></pre>
        </div>

        <div class="api-grid">
          <div class="api-item" v-reveal>
            <span class="method post">POST</span><code>/api/v1/charge</code>
            <p>Buat QRIS dinamis dengan nominal bebas.</p>
          </div>
          <div class="api-item" v-reveal>
            <span class="method get">GET</span><code>/api/v1/transaction/{order_id}/status</code>
            <p>Cek status pembayaran real-time.</p>
          </div>
          <div class="api-item" v-reveal>
            <span class="method post">POST</span><code>/api/v1/transaction/{order_id}/cancel</code>
            <p>Batalkan transaksi yang masih pending.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- FITUR -->
    <section id="fitur" class="sec">
      <div class="wrap">
        <div class="head" v-reveal>
          <span class="tag">FITUR</span>
          <h2>Bangun sistem bayar <em>tanpa drama</em></h2>
          <p>Satu API, semua kebutuhan payment merchant Indonesia.</p>
        </div>
        <div class="bento">
          <article v-for="f in features" :key="f.t" class="cell" :class="{ 'c-wide': f.wide }" v-reveal>
            <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" v-html="f.i"></svg></div>
            <h3>{{ f.t }}</h3>
            <p>{{ f.d }}</p>
          </article>
        </div>
      </div>
    </section>

    <!-- BIAYA -->
    <section id="biaya" class="sec sec-alt">
      <div class="wrap">
        <div class="head" v-reveal>
          <span class="tag">BIAYA</span>
          <h2>Tarif jelas, <em>tanpa biaya bulanan</em></h2>
        </div>
        <div class="fees">
          <div class="fee" v-reveal><span>Transaksi QRIS</span><b>{{ feeTransactionPercent }}%</b><p>Dipotong dari nominal yang berhasil dibayar.</p></div>
          <div class="fee" v-reveal><span>Penarikan dana</span><b>{{ wdFeePercent }}% + {{ rp(wdFeeFlat) }}</b><p>Biaya ditampilkan di depan sebelum kamu mengajukan.</p></div>
          <div class="fee" v-reveal><span>Minimal tarik</span><b>{{ rp(wdMin) }}</b><p>Saldo di atas batas ini bisa ditarik kapan saja.</p></div>
        </div>
      </div>
    </section>

    <!-- ALUR -->
    <section id="alur" class="sec">
      <div class="wrap">
        <div class="head" v-reveal>
          <span class="tag">ALUR</span>
          <h2>Empat langkah, langsung jalan</h2>
        </div>
        <div class="flow">
          <div class="fstep" v-reveal v-for="(st, i) in steps" :key="i">
            <span class="fnum">{{ st.n }}</span>
            <h3>{{ st.t }}</h3>
            <p>{{ st.d }}</p>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="sec sec-last">
      <div class="wrap">
        <div class="cta-card" v-reveal>
          <div class="cta-glow" aria-hidden="true"></div>
          <h2>Mulai terima QRIS <em>hari ini</em></h2>
          <p>Gratis, tanpa biaya bulanan. Cukup daftar dan ambil API key.</p>
          <NuxtLink to="/register" class="btn-white-xl">Daftar sekarang, gratis</NuxtLink>
          <span class="cta-foot">Sekitar 30 detik sampai dashboard aktif</span>
        </div>
      </div>
    </section>

    <SiteCopyright />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue'

const config = useRuntimeConfig()

const apiBase = computed(() => {
  const url = config.public.publicUrl || config.public.apiBaseUrl || ''
  if (url) return String(url).replace(/\/+$/, '')
  if (typeof window !== 'undefined') return window.location.origin
  return ''
})

const { heroTitle, heroLead, marqueeText, marqueeItems, marqueeBanks, bankLogos, feeTransactionPercent, wdFeePercent, wdFeeFlat, wdMin, load: loadSettings } = useSiteSettings()

const BANK_NAMES: Record<string, string> = {
  BCA: 'BCA', BNI: 'BNI', BRI: 'BRI', MANDIRI: 'Mandiri', CIMB: 'CIMB Niaga', PERMATA: 'Permata', DANAMON: 'Danamon',
  BSI: 'BSI', BTN: 'BTN', OCBC: 'OCBC NISP', MAYBANK: 'Maybank', PANIN: 'Panin', MEGA: 'Mega', BJB: 'BJB', DKI: 'Bank DKI',
  JAGO: 'Jago', SEABANK: 'SeaBank', NEO: 'Neo Commerce', BLU: 'blu', JENIUS: 'Jenius', GOPAY: 'GoPay', OVO: 'OVO',
  DANA: 'DANA', SHOPEEPAY: 'ShopeePay', LINKAJA: 'LinkAja',
}
const marquee = computed(() => {
  let codes = marqueeBanks.value.split(',').map(x => x.trim().toUpperCase()).filter(Boolean)
  if (!codes.length) codes = Object.keys(bankLogos.value)
  if (!codes.length) codes = marqueeItems.value.split(',').map(x => x.trim().toUpperCase().replace(/\s+/g, '')).filter(Boolean)
  return codes.map(c => ({ code: c, name: BANK_NAMES[c] || c, logo: bankLogos.value[c] || '' }))
})
const rp = (n: number) => 'Rp ' + Number(n || 0).toLocaleString('id-ID')
const titleParts = computed(() => {
  const t = heroTitle.value || 'Terima pembayaran QRIS tanpa ribet'
  const i = t.toUpperCase().indexOf('QRIS')
  return i < 0 ? [t, '', ''] : [t.slice(0, i), t.slice(i, i + 4), t.slice(i + 4)]
})

// QR dekoratif (deterministik)
const qrPath = (() => {
  const N = 25; let seed = 20261105
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296)
  const inFinder = (x: number, y: number) => (x < 8 && y < 8) || (x > N - 9 && y < 8) || (x < 8 && y > N - 9)
  let d = ''
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    if (!inFinder(x, y) && rnd() > 0.52) d += `M${x} ${y}h1v1h-1z`
  }
  for (const [fx, fy] of [[0, 0], [N - 7, 0], [0, N - 7]]) {
    d += `M${fx} ${fy}h7v7h-7z M${fx + 1} ${fy + 1}v5h5v-5z M${fx + 2} ${fy + 2}h3v3h-3z`
  }
  return d
})()

// parallax 3D
const stage = ref<HTMLElement | null>(null)
const rx = ref(-6), ry = ref(14)
function onMove(e: PointerEvent) {
  const el = stage.value; if (!el) return
  const r = el.getBoundingClientRect()
  const px = (e.clientX - r.left) / r.width - 0.5
  const py = (e.clientY - r.top) / r.height - 0.5
  ry.value = 14 + px * 22
  rx.value = -6 - py * 16
}
function onLeave() { rx.value = -6; ry.value = 14 }

const isScrolled = ref(false)
let scrollHandler: any = null

const tab = ref('cURL')
const copied = ref(false)

const snippets = computed<Record<string, string>>(() => ({
  cURL: `curl -X POST ${apiBase.value}/api/v1/charge \\
  -u CSPay-API-xxxxxxxx: \\
  -H "Content-Type: application/json" \\
  -d '{
    "payment_type": "qris",
    "transaction_details": {
      "order_id": "ORDER-1001",
      "gross_amount": 25000
    },
    "callback_url": "https://tokoku.id/callback"
  }'`,

  Node: `const res = await fetch("${apiBase.value}/api/v1/charge", {
  method: "POST",
  headers: {
    Authorization: "Basic " + Buffer.from("CSPay-API-xxxxxxxx:").toString("base64"),
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    payment_type: "qris",
    transaction_details: { order_id: "ORDER-1001", gross_amount: 25000 },
  }),
});

const trx = await res.json();
console.log(trx.payment_url);`,

  PHP: `$ch = curl_init("${apiBase.value}/api/v1/charge");
curl_setopt_array($ch, [
  CURLOPT_POST => true,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_USERPWD => "CSPay-API-xxxxxxxx:",
  CURLOPT_HTTPHEADER => ["Content-Type: application/json"],
  CURLOPT_POSTFIELDS => json_encode([
    "payment_type" => "qris",
    "transaction_details" => ["order_id" => "ORDER-1001", "gross_amount" => 25000],
  ]),
]);
$trx = json_decode(curl_exec($ch), true);
echo $trx["payment_url"];`,

  Python: `import requests

r = requests.post(
  "${apiBase.value}/api/v1/charge",
  auth=("CSPay-API-xxxxxxxx", ""),
  json={
    "payment_type": "qris",
    "transaction_details": {"order_id": "ORDER-1001", "gross_amount": 25000},
  },
)
print(r.json()["payment_url"])`,
}))

const features = [
  { wide: true, t: 'QRIS Dinamis', d: 'Nominal bebas, kode unik per transaksi, terdeteksi otomatis lewat polling. Tidak ada saldo mengambang.', i: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M14 20v.01M20 20h-3v-3"/>' },
  { t: 'Callback Otomatis', d: 'Notifikasi ke server kamu saat lunas, auto-retry sampai 12 kali kalau gagal.', i: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>' },
  { t: 'Dashboard Live', d: 'Transaksi, grafik omzet, dan saldo yang diperbarui real-time.', i: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>' },
  { t: 'Multi API Key', d: 'Isolasi per project. Rotate key tanpa downtime.', i: '<circle cx="8" cy="15" r="4"/><path d="M10.8 12.2L20 3M16 7l3 3M14 9l2 2"/>' },
  { wide: true, t: 'Penarikan Dana', d: 'Ajukan withdraw kapan saja. Biaya jelas di depan, status jelas di dashboard.', i: '<path d="M12 3v14M6 11l6 6 6-6"/><path d="M4 21h16"/>' },
]

const steps = [
  { n: '01', t: 'Daftar merchant', d: 'Akun gratis, aktif dalam 30 detik.' },
  { n: '02', t: 'Ambil API key', d: 'Generate langsung dari dashboard.' },
  { n: '03', t: 'Integrasi', d: 'Satu endpoint POST, contoh kode tersedia.' },
  { n: '04', t: 'Terima & tarik', d: 'Dana mengalir sesuai settlement.' },
]

async function copyCode() {
  const text = snippets[tab.value]
  let ok = false
  try { await navigator.clipboard.writeText(text); ok = true } catch {
    const ta = document.createElement('textarea')
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'
    document.body.appendChild(ta); ta.select()
    try { ok = document.execCommand('copy') } catch {}
    document.body.removeChild(ta)
  }
  if (ok) { copied.value = true; setTimeout(() => (copied.value = false), 1500) }
}

const vReveal = {
  mounted(el: HTMLElement) {
    el.classList.add('rv')
    const obs = new IntersectionObserver(es => {
      es.forEach(e => {
        if (e.isIntersecting) { el.classList.add('rv-in'); obs.unobserve(el) }
      })
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' })
    obs.observe(el)
  },
}

onMounted(() => {
  loadSettings()
  scrollHandler = () => { isScrolled.value = window.scrollY > 20 }
  window.addEventListener('scroll', scrollHandler, { passive: true })
  scrollHandler()
})
onBeforeUnmount(() => {
  if (scrollHandler) window.removeEventListener('scroll', scrollHandler)
})
</script>

<style scoped>
* { box-sizing: border-box; margin: 0; padding: 0; }
.landing { position: relative; min-height: 100vh; color: var(--txt); background: var(--card); -webkit-font-smoothing: antialiased; overflow-x: clip; }
.wrap { max-width: 1160px; margin: 0 auto; padding: 0 24px; }

/* NAV */
.nav { position: sticky; top: 0; z-index: 100; background: rgba(255,255,255,.82); backdrop-filter: blur(16px) saturate(160%); -webkit-backdrop-filter: blur(16px) saturate(160%); border-bottom: 1px solid transparent; transition: border-color .3s, box-shadow .3s; }
.nav-on { border-bottom-color: var(--line); box-shadow: 0 6px 24px -16px rgba(var(--shadow-rgb),.35); }
.nav-in { max-width: 1160px; margin: 0 auto; padding: 0 24px; height: 66px; display: flex; align-items: center; gap: 16px; }
.brand { display: flex; align-items: center; flex-shrink: 0; }
.brand :deep(img) { height: 32px; width: auto; display: block; }
.links { display: flex; gap: 28px; margin: 0 auto; font-size: 13.5px; font-weight: 600; color: var(--dim); }
.links a:hover { color: var(--vio); }
.cta-nav { display: flex; gap: 8px; align-items: center; }
.btn-soft { padding: 9px 16px; font-size: 13px; font-weight: 700; border-radius: 10px; color: var(--txt); }
.btn-soft:hover { background: var(--bg-soft); color: var(--vio); }
.btn-grad { display: inline-flex; align-items: center; justify-content: center; padding: 10px 18px; font-size: 13px; font-weight: 700; color: #fff; background: var(--grad); border-radius: 10px; box-shadow: 0 8px 22px -8px rgba(var(--vio-rgb),.65); transition: transform .2s, box-shadow .2s; }
.btn-grad:hover { color: #fff; transform: translateY(-2px); box-shadow: 0 14px 30px -10px rgba(var(--vio-rgb),.75); }
.btn-ghost { display: inline-flex; align-items: center; padding: 10px 18px; font-size: 13px; font-weight: 700; border-radius: 10px; border: 1px solid rgba(255,255,255,.22); color: #fff; transition: background .2s; }
.btn-ghost:hover { background: rgba(255,255,255,.08); color: #fff; }
.btn-ghost-d { display: inline-flex; padding: 10px 18px; font-size: 13px; font-weight: 700; border-radius: 10px; border: 1px solid var(--line-2); }
.btn-ghost-d:hover { border-color: var(--vio); }
.btn-xl { padding: 14px 24px; font-size: 14.5px; border-radius: 12px; }

/* HERO */
.hero { position: relative; background: #070d1f; color: #fff; overflow: hidden; padding: 72px 0 96px; }
.hero-grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(45,212,191,.08) 1px, transparent 1px), linear-gradient(90deg, rgba(45,212,191,.08) 1px, transparent 1px); background-size: 52px 52px; mask-image: radial-gradient(ellipse 80% 70% at 60% 40%, #000 30%, transparent 80%); -webkit-mask-image: radial-gradient(ellipse 80% 70% at 60% 40%, #000 30%, transparent 80%); }
.hero-glow { position: absolute; border-radius: 50%; filter: blur(110px); pointer-events: none; }
.g1 { width: 560px; height: 560px; right: -120px; top: -160px; background: rgba(var(--vio-rgb),.5); }
.g2 { width: 420px; height: 420px; left: -140px; bottom: -200px; background: rgba(14,165,233,.28); }
.hero-in { position: relative; display: grid; grid-template-columns: 1.02fr 1fr; gap: 24px; align-items: center; }
.chip { display: inline-flex; align-items: center; gap: 8px; padding: 6px 14px; border-radius: 999px; font-size: 12px; font-weight: 600; color: #99f6e4; background: rgba(45,212,191,.1); border: 1px solid rgba(45,212,191,.22); }
.dot { width: 7px; height: 7px; border-radius: 50%; background: #2dd4bf; box-shadow: 0 0 0 4px rgba(45,212,191,.18); animation: pulse 2s infinite; }
@keyframes pulse { 50% { box-shadow: 0 0 0 7px rgba(45,212,191,0); } }
.h1 { margin-top: 22px; font-size: clamp(36px, 5.2vw, 62px); line-height: 1.04; font-weight: 800; letter-spacing: -0.035em; }
.mark { background: linear-gradient(120deg, var(--vio-2), #2dd4bf); -webkit-background-clip: text; background-clip: text; color: transparent; }
.sub { margin-top: 20px; max-width: 490px; font-size: 16.5px; line-height: 1.65; color: #94a3b8; }
.hero-cta { margin-top: 32px; display: flex; gap: 12px; flex-wrap: wrap; }
.hero-stats { margin-top: 44px; display: flex; gap: 36px; }
.hero-stats dt { font-size: 24px; font-weight: 800; letter-spacing: -0.02em; }
.hero-stats dd { margin-top: 2px; font-size: 12px; color: #94a3b8; }

/* 3D STAGE */
.stage { position: relative; height: 480px; perspective: 1300px; display: flex; align-items: center; justify-content: center; touch-action: pan-y; }
.scene { position: relative; width: 360px; height: 360px; transform-style: preserve-3d; transition: transform .35s cubic-bezier(.2,.8,.2,1); }
.floor { position: absolute; left: 50%; top: 50%; width: 420px; height: 420px; margin: -210px 0 0 -210px; transform: translateZ(-120px); border-radius: 50%; background: radial-gradient(circle, rgba(var(--vio-rgb),.5), transparent 65%); filter: blur(20px); }
.plate { position: absolute; left: 50%; top: 80px; margin-left: -175px; width: 350px; height: 230px; padding: 16px 18px; border-radius: 18px; background: linear-gradient(145deg, rgba(15,23,42,.92), rgba(7,13,31,.94)); border: 1px solid rgba(45,212,191,.28); box-shadow: 0 40px 80px -24px rgba(0,0,0,.7), inset 0 1px 0 rgba(255,255,255,.1); animation: bob 7s ease-in-out infinite; }
.plate-bar { display: flex; gap: 6px; margin-bottom: 14px; }
.plate-bar i { width: 8px; height: 8px; border-radius: 50%; background: rgba(255,255,255,.2); }
.plate-row { display: flex; flex-direction: column; gap: 2px; font-size: 11px; color: #94a3b8; }
.plate-row b { font-size: 22px; color: #fff; letter-spacing: -0.02em; }
.plate-chart { position: absolute; left: 18px; right: 18px; bottom: 14px; width: calc(100% - 36px); height: 82px; }
.paid { position: absolute; right: -6px; top: 20px; display: flex; align-items: center; gap: 10px; padding: 12px 16px 12px 12px; border-radius: 16px; background: rgba(255,255,255,.96); color: var(--txt); transform: translateZ(120px); box-shadow: 0 24px 50px -14px rgba(0,0,0,.6); animation: bob 5.5s ease-in-out -1s infinite; }
.paid b { display: block; font-size: 12.5px; }
.paid span { font-size: 11px; color: var(--dim); }
.paid-ic { width: 32px; height: 32px; border-radius: 10px; background: #0d9488; color: #fff; display: grid; place-items: center; flex-shrink: 0; }
&.stat { position: absolute; left: -6px; bottom: 36px; width: 170px; padding: 12px 14px; border-radius: 14px; background: rgba(255,255,255,.96); color: var(--txt); transform: translateZ(90px); box-shadow: 0 24px 50px -14px rgba(0,0,0,.55); animation: bob 6s ease-in-out -2s infinite; }
.stat span { display: block; font-size: 11px; color: var(--dim); }
.stat b { display: block; font-size: 18px; letter-spacing: -0.02em; margin: 2px 0 8px; }
.stat i { display: block; height: 5px; border-radius: 999px; background: var(--line); overflow: hidden; }
.stat u { display: block; height: 100%; background: var(--vio); border-radius: 999px; }
@keyframes spin { to { transform: rotateY(360deg); } }
@keyframes bob { 50% { margin-top: -10px; } }

/* MARQUEE */
.mq { padding: 48px 0 44px; border-bottom: 1px solid var(--line); background: var(--card); }
.mq-t { text-align: center; font-size: 13px; font-weight: 800; letter-spacing: .06em; text-transform: uppercase; color: var(--dim); margin-bottom: 28px; }
.mq-view { overflow: hidden; mask-image: linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent); -webkit-mask-image: linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent); }
.mq-track { display: flex; width: max-content; align-items: center; animation: mq calc(var(--n) * 3.8s) linear infinite; }
.mq-view:hover .mq-track { animation-play-state: paused; }
.mq-item { height: 76px; min-width: 190px; margin: 0 36px; display: flex; align-items: center; justify-content: center; }
.mq-item img { height: 60px; width: auto; max-width: 240px; object-fit: contain; filter: grayscale(1) opacity(.8); transition: filter .25s, transform .25s; }
.mq-item:hover img { filter: none; transform: scale(1.05); }
.mq-item span { font-size: 30px; font-weight: 800; letter-spacing: -0.02em; color: #b8a3a7; white-space: nowrap; }
@keyframes mq { to { transform: translateX(-50%); } }

/* SECTIONS */
.sec { padding: 96px 0; }
.sec-alt { background: var(--bg-soft); border-block: 1px solid var(--line); }
.sec-last { padding-bottom: 72px; }
.head { text-align: center; max-width: 620px; margin: 0 auto 52px; }
.tag { display: inline-block; font-size: 11.5px; font-weight: 800; letter-spacing: .14em; color: var(--vio); }
.head h2, .api-head h2 { margin-top: 10px; font-size: clamp(28px, 3.6vw, 40px); line-height: 1.12; font-weight: 800; letter-spacing: -0.03em; }
.head p { margin-top: 12px; color: var(--dim); font-size: 15.5px; }
em { font-style: normal; background: var(--grad); -webkit-background-clip: text; background-clip: text; color: transparent; }

/* API */
.api { padding: 88px 0; background: var(--card); }
.api-head { display: flex; justify-content: space-between; align-items: flex-end; gap: 16px; flex-wrap: wrap; margin-bottom: 28px; }
.api-shell { border-radius: 18px; overflow: hidden; background: var(--txt); box-shadow: 0 30px 70px -24px rgba(var(--shadow-rgb),.5); }
.api-tabs { display: flex; align-items: center; gap: 4px; padding: 10px 12px; border-bottom: 1px solid rgba(255,255,255,.08); overflow-x: auto; scrollbar-width: none; }
.api-tabs::-webkit-scrollbar { display: none; }
.api-tab { flex: none; }
.api-tab { padding: 7px 14px; font-size: 12.5px; font-weight: 700; color: #94a3b8; border-radius: 8px; transition: all .15s; }
.api-tab:hover { color: #fff; }
.api-tab.active { background: rgba(45,212,191,.16); color: #fff; }
.api-copy { flex: none; position: sticky; right: 0; background: var(--txt); margin-left: auto; padding: 7px 14px; font-size: 12px; font-weight: 700; color: #99f6e4; border: 1px solid rgba(45,212,191,.25); border-radius: 8px; }
.api-copy:hover { background: rgba(45,212,191,.12); }
.api-code { padding: 22px 24px; white-space: pre-wrap; overflow-wrap: anywhere; word-break: break-word; font-family: 'JetBrains Mono', ui-monospace, Menlo, monospace; font-size: 13px; line-height: 1.7; color: #e2e8f0; }
.api-grid { margin-top: 18px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.api-item { padding: 18px 20px; border: 1px solid var(--line); border-radius: 14px; background: var(--card); transition: border-color .2s, transform .2s; }
.api-item:hover { border-color: var(--vio-2); transform: translateY(-3px); }
.method { font-size: 10.5px; font-weight: 800; padding: 3px 8px; border-radius: 6px; margin-right: 8px; }
.method.post { background: rgba(var(--vio-rgb),.1); color: var(--vio); }
.method.get { background: rgba(13,148,136,.1); color: var(--ok); }
.api-item { min-width: 0; }
.api-item code { font-size: 12.5px; font-weight: 600; overflow-wrap: anywhere; word-break: break-word; }
.api-item p { margin-top: 10px; font-size: 13px; color: var(--dim); }

/* BENTO */
.bento { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.cell { padding: 28px; border: 1px solid var(--line); border-radius: 20px; background: var(--card); transition: transform .25s, box-shadow .25s, border-color .25s; }
.cell:hover { transform: translateY(-4px); border-color: var(--vio-2); box-shadow: var(--shadow-md); }
.c-wide { grid-column: span 2; }
.ic { width: 44px; height: 44px; border-radius: 12px; display: grid; place-items: center; background: var(--grad); color: #fff; box-shadow: 0 10px 22px -10px rgba(var(--vio-rgb),.7); }
.ic svg { width: 22px; height: 22px; }
.cell h3 { margin-top: 18px; font-size: 18px; font-weight: 800; letter-spacing: -0.01em; }
.cell p { margin-top: 8px; font-size: 14px; line-height: 1.65; color: var(--dim); }

/* BIAYA */
.fees { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.fee { padding: 28px; border-radius: 20px; background: var(--card); border: 1px solid var(--line); }
.fee span { font-size: 12.5px; font-weight: 700; color: var(--dim); }
.fee b { display: block; margin: 10px 0 8px; font-size: 28px; font-weight: 800; letter-spacing: -0.03em; }
.fee p { font-size: 13px; color: var(--dim); line-height: 1.6; }

/* ALUR */
.flow { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; position: relative; }
.fstep { padding: 24px; border-radius: 18px; border: 1px solid var(--line); background: var(--card); }
.fnum { font-size: 13px; font-weight: 800; color: var(--vio); letter-spacing: .06em; }
.fstep h3 { margin-top: 12px; font-size: 16px; font-weight: 800; }
.fstep p { margin-top: 6px; font-size: 13.5px; color: var(--dim); line-height: 1.6; }

/* CTA */
.cta-card { position: relative; overflow: hidden; text-align: center; padding: 72px 24px; border-radius: 28px; color: #fff; background: #070d1f; }
.cta-glow { position: absolute; inset: auto -10% -60% -10%; height: 90%; background: radial-gradient(ellipse at center, rgba(var(--vio-rgb),.65), transparent 70%); }
.cta-card > * { position: relative; }
.cta-card h2 { font-size: clamp(28px, 4vw, 42px); font-weight: 800; letter-spacing: -0.03em; }
.cta-card p { margin: 12px 0 28px; color: #94a3b8; }
.btn-white-xl { display: inline-block; padding: 14px 28px; border-radius: 12px; background: var(--card); color: var(--txt); font-weight: 800; font-size: 14.5px; transition: transform .2s; }
.btn-white-xl:hover { transform: translateY(-2px); color: var(--vio); }
.cta-foot { display: block; margin-top: 16px; font-size: 12px; color: #94a3b8; }

/* REVEAL */
.rv { opacity: 0; transform: translateY(22px); transition: opacity .6s ease, transform .6s cubic-bezier(.2,.8,.2,1); }
.rv-in { opacity: 1; transform: none; }

@media (max-width: 960px) {
  .api-grid { grid-template-columns: 1fr; }
  .api-code { padding: 16px; font-size: 12px; }
  .links { display: none; }
  .cta-nav { margin-left: auto; }
  .hero { padding: 48px 0 64px; }
  .hero-in { grid-template-columns: 1fr; }
  .stage { height: 400px; margin-top: 12px; }
  .scene { transform-origin: center; zoom: .9; }
  .bento, .fees, .api-grid { grid-template-columns: 1fr; }
  .c-wide { grid-column: auto; }
  .flow { grid-template-columns: 1fr 1fr; }
  .hero-stats { gap: 22px; }
}
@media (max-width: 960px) {
  .mq { padding: 42px 0 38px; }
  .mq-item { height: 64px; min-width: 150px; margin: 0 28px; }
  .mq-item img { height: 48px; max-width: 190px; }
  .mq-item span { font-size: 25px; }
}
@media (max-width: 480px) {
  .flow { grid-template-columns: 1fr; }
  .stage { height: 330px; }
  .scene { zoom: .72; }
  .mq { padding: 36px 0 32px; }
  .mq-t { margin-bottom: 22px; font-size: 12.5px; }
  .mq-item { height: 54px; min-width: 128px; margin: 0 24px; }
  .mq-item img { height: 44px; max-width: 165px; }
  .mq-item span { font-size: 22px; }
}
@media (prefers-reduced-motion: reduce) {
  .plate, .paid, .stat, .mq-track, .dot { animation: none !important; }
  .rv { opacity: 1; transform: none; transition: none; }
}
</style>
